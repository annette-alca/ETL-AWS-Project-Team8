def lambda_extract():
    return "team8"

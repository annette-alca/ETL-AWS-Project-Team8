def lambda_extract(events, context):
    return "team8"
